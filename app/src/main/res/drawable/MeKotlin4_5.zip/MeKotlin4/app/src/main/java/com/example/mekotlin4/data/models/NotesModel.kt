package com.example.mekotlin4.data.models

import android.icu.text.CaseMap.Title

data class NotesModel(
    val title: String,
    val note : String,
    val data : String
)
